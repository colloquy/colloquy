#ifndef __AUTORUN_H
#define __AUTORUN_H

void autorun_startup(void);

#endif
