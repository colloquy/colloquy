#include "common.h"
#include "iconfig.h"

/* private */
int config_error(CONFIG_REC *rec, const char *msg);

