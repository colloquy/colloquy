/* automatically created by configure */
#define IRSSI_VERSION "0.8.9"
#define IRSSI_VERSION_DATE 20031210
#define IRSSI_VERSION_TIME 2316
