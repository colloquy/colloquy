/* automatically created by configure */
#define IRSSI_VERSION "0.8.10-rc5"
#define IRSSI_VERSION_DATE 20041018
#define IRSSI_VERSION_TIME 1440
