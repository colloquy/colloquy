/* automatically created by configure */
#define IRSSI_VERSION "0.8.10-rc4"
#define IRSSI_VERSION_DATE 20040714
#define IRSSI_VERSION_TIME 1212
